const apiEndpoint = "/api/chat";

const chatEl = document.getElementById("chat");
const inputEl = document.getElementById("input");
const sendBtn = document.getElementById("send");
const micBtn = document.getElementById("mic");
const modeSel = document.getElementById("mode");
const ttsToggle = document.getElementById("tts-toggle");
const snd = document.getElementById("snd");

function appendBubble(text, who="bot", meta="") {
  const wrap = document.createElement("div");
  wrap.className = "bubble " + (who==="user" ? "user" : "bot");
  if (meta) {
    const m = document.createElement("div"); m.className="meta"; m.textContent = meta;
    wrap.appendChild(m);
  }
  const p = document.createElement("div"); p.className="content"; wrap.appendChild(p);
  chatEl.appendChild(wrap);
  chatEl.scrollTop = chatEl.scrollHeight;
  return p;
}

function typeEffect(container, text, speed=18) {
  container.textContent = "";
  return new Promise(resolve=>{
    let i=0;
    const t = setInterval(()=>{
      container.textContent += text.charAt(i);
      i++;
      chatEl.scrollTop = chatEl.scrollHeight;
      if (i>=text.length) { clearInterval(t); resolve(); }
    }, speed);
  });
}

async function sendMessage() {
  const text = inputEl.value.trim();
  if (!text) return;
  const userMeta = new Date().toLocaleString();
  const userContainer = appendBubble(text, "user", userMeta);
  inputEl.value = "";
  snd.currentTime = 0; snd.play().catch(()=>{});

  // placeholder bot bubble while waiting:
  const placeholder = appendBubble("Laila está digitando...", "bot", "");
  const botTextContainer = placeholder.querySelector(".content");

  try {
    const resp = await fetch(apiEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, mode: modeSel.value, persist: true })
    });

    const data = await resp.json();
    placeholder.remove();
    if (data.error) {
      appendBubble("Erro: " + data.error, "bot");
      return;
    }
    const reply = data.reply || "Desculpe, sem resposta.";
    const botContainer = appendBubble("", "bot", new Date().toLocaleString());
    await typeEffect(botContainer, reply);
    if (ttsToggle && ttsToggle.textContent === "🔊") speak(reply);
  } catch (e) {
    placeholder.remove();
    appendBubble("Erro de conexão.", "bot");
    console.error(e);
  }
}

// TTS
function speak(text) {
  try {
    if (!("speechSynthesis" in window)) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "pt-BR"; u.rate = 1; u.volume = 1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  } catch (e) { console.warn(e); }
}

// STT (simple)
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recog = new SpeechRecognition();
  recog.lang = "pt-BR"; recog.interimResults = false; recog.continuous = false;
  recog.onresult = e => { inputEl.value = e.results[0][0].transcript; };
  recog.onerror = e => console.warn("STT error", e);
  micBtn.addEventListener("click", ()=>{ try { recog.start(); } catch(e){ console.warn(e); } });
} else {
  micBtn.style.opacity = 0.4; micBtn.title = "Navegador sem STT";
}

sendBtn.addEventListener("click", sendMessage);
inputEl.addEventListener("keydown", e => { if (e.key === "Enter") sendMessage(); });

// small UI init: make tts-toggle show on/off state
ttsToggle.addEventListener("click", ()=>{
  if (ttsToggle.textContent === "🔊") { ttsToggle.textContent = "🔇"; } else { ttsToggle.textContent = "🔊"; }
});
