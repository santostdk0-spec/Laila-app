-- Enable extensions
create extension if not exists "pg_trgm";
create extension if not exists "vector";
create extension if not exists "pgcrypto";

-- semantic memory table with embedding vector
create table if not exists memories (
  id text primary key,
  content text not null,
  metadata jsonb,
  embedding vector(1536),
  created_at timestamptz default now()
);

-- raw message audit table
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  user_message text not null,
  bot_reply text not null,
  created_at timestamptz default now()
);

-- RPC for nearest neighbors (assumes vector type available)
create or replace function match_memories(query_embedding vector(1536), match_threshold float, match_count int)
returns table(id text, content text, metadata jsonb, similarity float) as $$
  select id, content, metadata, 1 - (embedding <#> query_embedding) as similarity
  from memories
  where embedding is not null
  order by embedding <#> query_embedding
  limit match_count;
$$ language sql stable;
