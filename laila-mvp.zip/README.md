# LAILA — Full app package

This archive contains a ready-to-deploy PWA + serverless handlers for LAILA.

## Quick start (deploy to Vercel)
1. Create a GitHub repo and push this project (root contains package.json and api/ and public/).
2. On Supabase, run `sql/supabase_schema.sql` in the SQL Editor.
3. In Vercel, create a new project connected to this repo.
4. In Vercel > Settings > Environment Variables add:
   - OPENAI_API_KEY (sk-...)
   - SUPABASE_URL (https://...supabase.co)
   - SUPABASE_SERVICE_KEY (service_role key from Supabase)
   - SUPABASE_MEMORY_TABLE (optional)
   - SUPABASE_MSG_TABLE (optional)
   - ADMIN_PASSWORD (optional)
5. Deploy. Test with `POST /api/chat`.

## Notes
- Do NOT put service keys in client code.
- Monitor OpenAI token usage.

