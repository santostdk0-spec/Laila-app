import { supabaseAdmin } from "../lib/supabase.js";
import { createEmbedding, callResponsesAPI } from "../lib/openai.js";

const RESP_MODEL = "gpt-4.1-mini";
const EMB_MODEL = "text-embedding-3-small";
const TOP_K = 4;
const MEMORY_TABLE = process.env.SUPABASE_MEMORY_TABLE || "memories";
const MSG_TABLE = process.env.SUPABASE_MSG_TABLE || "messages";

function extractReply(resp) {
  if (!resp) return null;
  if (typeof resp.output_text === "string" && resp.output_text.trim()) return resp.output_text.trim();
  const out0 = resp.output?.[0];
  if (out0?.content) {
    for (const c of out0.content) {
      if (c?.type === "output_text" && c?.text) return c.text.trim();
    }
    for (const c of out0.content) {
      if (typeof c?.text === "string" && c.text.trim()) return c.text.trim();
    }
  }
  if (Array.isArray(resp.choices) && resp.choices[0]?.message?.content) {
    const msg = resp.choices[0].message.content;
    if (typeof msg === "string" && msg.trim()) return msg.trim();
    if (msg?.text) return String(msg.text).trim();
  }
  return null;
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const body = req.body || {};
    const message = (body.message || "").toString();
    const persist = body.persist === undefined ? true : !!body.persist;
    const mode = (body.mode || "reflexiva").toString();

    if (!message) return res.status(400).json({ error: "Empty message" });

    const now = new Date();
    const dateStr = now.toLocaleDateString("pt-BR");
    const timeStr = now.toLocaleTimeString("pt-BR");

    // try semantic retrieval if supabase configured
    let memories = [];
    let embedding = null;
    if (supabaseAdmin) {
      try {
        embedding = await createEmbedding(message, EMB_MODEL);
        if (embedding) {
          const rpcUrl = `${process.env.SUPABASE_URL}/rpc/match_memories`;
          const rpcResp = await fetch(rpcUrl, {
            method: "POST",
            headers: {
              "apikey": process.env.SUPABASE_SERVICE_KEY,
              "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ query_embedding: embedding, match_threshold: 0.0, match_count: TOP_K })
          });
          if (rpcResp.ok) memories = await rpcResp.json();
        }
      } catch (e) {
        console.warn("memory retrieval error:", e?.message || e);
      }
    }

    // build persona + memory context
    let persona = `Você é LAILA, assistente privada, objetiva e estratégica. Modo: ${mode}.
Data: ${dateStr}, Hora: ${timeStr}. Responda com clareza e concisão.`;

    if (Array.isArray(memories) && memories.length) {
      persona += `\nMemórias relevantes:\n` + memories.map((m,i)=>`${i+1}. ${m.content}`).join("\n");
    }

    const payload = {
      model: RESP_MODEL,
      input: [
        { role: "system", content: persona },
        { role: "user", content: message }
      ],
      max_output_tokens: 700,
      temperature: 0.25
    };

    const openaiResp = await callResponsesAPI(payload);
    const reply = extractReply(openaiResp) || "Desculpe, não consegui gerar uma resposta.";

    // save audit message (best-effort)
    if (supabaseAdmin) {
      try {
        await fetch(`${process.env.SUPABASE_URL}/rest/v1/${MSG_TABLE}`, {
          method: "POST",
          headers: {
            "apikey": process.env.SUPABASE_SERVICE_KEY,
            "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
            "Content-Type": "application/json",
            "Prefer": "return=representation"
          },
          body: JSON.stringify([{ user_message: message, bot_reply: reply }])
        });
      } catch (e) {
        console.warn("audit save failed:", e?.message || e);
      }
    }

    // persist semantic memory (best-effort)
    let memory_saved = false;
    if (persist && embedding && supabaseAdmin) {
      try {
        const id = `${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
        const snippet = message.length > 800 ? message.slice(0,800) : message;
        const meta = { mode, created_at: new Date().toISOString() };
        const insResp = await fetch(`${process.env.SUPABASE_URL}/rest/v1/${MEMORY_TABLE}`, {
          method: "POST",
          headers: {
            "apikey": process.env.SUPABASE_SERVICE_KEY,
            "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
            "Content-Type": "application/json",
            "Prefer": "return=representation"
          },
          body: JSON.stringify({ id, content: snippet, metadata: meta, embedding })
        });
        memory_saved = insResp.ok;
      } catch (e) {
        console.warn("memory persist failed:", e?.message || e);
      }
    }

    return res.status(200).json({ reply, retrieved_count: memories.length || 0, memory_saved });

  } catch (err) {
    console.error("handler error:", err);
    return res.status(500).json({ error: "Server error", detail: String(err) });
  }
}
